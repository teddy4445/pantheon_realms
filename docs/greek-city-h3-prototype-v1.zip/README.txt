GREEK POLIS — HEROES III INSPIRED ART PROTOTYPE

Open preview.html in a browser to test the city.
Open contact-sheet.html to inspect all 18 transparent building assets.

DELIVERABLES
full-city.png — complete concept painting.
background.png — reconstructed terrain plate, with gameplay buildings removed.
buildings/*.png — 18 individual transparent building/complex assets.
manifest.json — building IDs, relative image paths and initial placements.
manifest.js — the same manifest packaged for a preview that opens without a server.
prompts.json — full generation and extraction prompts.
assembled-preview.png — screenshot of the actual background + building layers.
contact-sheet.png — screenshot of all building assets on checkerboard.
validation.json — dimensions, transparency checks and preview checks.

CONTROLS
Show all: reveal all buildings.
Background only: hide all buildings.
View concept: compare the independent layers against the original painting.
Click a building or its name to select it.
Drag the selected building to move it.
Width changes its scale. Depth changes its overlap order.
Checkboxes toggle individual buildings.
Reset layout returns to the supplied placement.
Export placement JSON downloads your adjusted layout. Changes are not autosaved.

PLACEMENT FORMAT
x = horizontal center as percent of scene width.
y = bottom edge as percent of scene height.
width = image width as percent of scene width.
layer = stacking order, higher numbers draw on top.
Image dimensions and transparent padding matter when tuning the final position.
The scene is 3:2. The current game's town scene uses a different aspect ratio,
so adopting this artwork requires a coordinated aspect-ratio and placement change.

SCOPE AND LIMITATIONS
This is an isolated visual test kit, not integrated game content.
Each of the 18 existing town slots has one developed visual variant.
Individual earlier upgrade stages and damaged variants are not included.
Images were generated with the built-in image generation tool.
The background and transparent assets are reconstructions guided by the concept,
not a lossless decomposition. Some architectural details can differ.
Final game integration will need click regions, foreground occlusion and
ground-contact refinements, plus appropriate asset-resolution choices.
The preview uses rectangular image hit regions for dragging.

REPEAT VALIDATION
From the repository root:
node docs/greek-city-h3-prototype-v1/verify.mjs

This launches a temporary local server and headless Chromium, checks that all
18 images load with transparency, exercises the preview controls, and saves
the assembled scene, asset contact sheet and validation results.
