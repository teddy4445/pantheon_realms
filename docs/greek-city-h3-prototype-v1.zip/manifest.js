window.CITY_MANIFEST = {
  "name": "Greek Polis — Heroes III inspired prototype",
  "version": 1,
  "aspectRatio": "3:2",
  "background": "background.png",
  "reference": "full-city.png",
  "anchor": "center-bottom",
  "buildings": [
    {
      "id": "pantheon_temple",
      "name": "Pantheon Temple",
      "x": 48,
      "y": 26,
      "width": 31,
      "layer": 2,
      "file": "buildings/pantheon_temple.png",
      "visible": true
    },
    {
      "id": "mage_guild",
      "name": "Sanctum",
      "x": 74,
      "y": 23,
      "width": 13,
      "layer": 3,
      "file": "buildings/mage_guild.png",
      "visible": true
    },
    {
      "id": "watchtower",
      "name": "Watchtower",
      "x": 92,
      "y": 19,
      "width": 9,
      "layer": 2,
      "file": "buildings/watchtower.png",
      "visible": true
    },
    {
      "id": "civic_hall",
      "name": "Civic Capitol",
      "x": 57,
      "y": 36,
      "width": 23,
      "layer": 4,
      "file": "buildings/civic_hall.png",
      "visible": true
    },
    {
      "id": "tavern",
      "name": "Tavern",
      "x": 42,
      "y": 44,
      "width": 20,
      "layer": 5,
      "file": "buildings/tavern.png",
      "visible": true
    },
    {
      "id": "artifact_merchant",
      "name": "Artifact Merchant",
      "x": 67,
      "y": 47,
      "width": 18,
      "layer": 5,
      "file": "buildings/artifact_merchant.png",
      "visible": true
    },
    {
      "id": "marketplace",
      "name": "Marketplace",
      "x": 55,
      "y": 57,
      "width": 23,
      "layer": 6,
      "file": "buildings/marketplace.png",
      "visible": true
    },
    {
      "id": "training_academy",
      "name": "Training Academy",
      "x": 86,
      "y": 62,
      "width": 21,
      "layer": 7,
      "file": "buildings/training_academy.png",
      "visible": true
    },
    {
      "id": "workshop",
      "name": "Workshop",
      "x": 28,
      "y": 68,
      "width": 16,
      "layer": 8,
      "file": "buildings/workshop.png",
      "visible": true
    },
    {
      "id": "resource_depot",
      "name": "Resource Depot",
      "x": 43,
      "y": 69,
      "width": 17,
      "layer": 8,
      "file": "buildings/resource_depot.png",
      "visible": true
    },
    {
      "id": "fortifications",
      "name": "Fortifications",
      "x": 63,
      "y": 101,
      "width": 66,
      "layer": 12,
      "file": "buildings/fortifications.png",
      "visible": true
    },
    {
      "id": "dwelling_t1",
      "name": "Barracks",
      "x": 65,
      "y": 73,
      "width": 20,
      "layer": 9,
      "file": "buildings/dwelling_t1.png",
      "visible": true
    },
    {
      "id": "dwelling_t2",
      "name": "Peltast Range",
      "x": 87,
      "y": 73,
      "width": 18,
      "layer": 10,
      "file": "buildings/dwelling_t2.png",
      "visible": true
    },
    {
      "id": "dwelling_t3",
      "name": "Griffin Aerie",
      "x": 92.5,
      "y": 45,
      "width": 11,
      "layer": 5,
      "file": "buildings/dwelling_t3.png",
      "visible": true
    },
    {
      "id": "dwelling_t4",
      "name": "Training Court",
      "x": 27,
      "y": 39,
      "width": 17,
      "layer": 4,
      "file": "buildings/dwelling_t4.png",
      "visible": true
    },
    {
      "id": "dwelling_t5",
      "name": "House of Adepts",
      "x": 14,
      "y": 40,
      "width": 13,
      "layer": 4,
      "file": "buildings/dwelling_t5.png",
      "visible": true
    },
    {
      "id": "dwelling_t6",
      "name": "Labyrinth",
      "x": 84,
      "y": 47,
      "width": 15,
      "layer": 5,
      "file": "buildings/dwelling_t6.png",
      "visible": true
    },
    {
      "id": "dwelling_t7",
      "name": "Thunder Quarry",
      "x": 12,
      "y": 74,
      "width": 24,
      "layer": 7,
      "file": "buildings/dwelling_t7.png",
      "visible": true
    }
  ]
};
