import { chromium } from '@playwright/test';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const server=createServer(async(req,res)=>{
  const target=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!target.startsWith(root+path.sep)){res.writeHead(403);res.end();return}
  try { const body=await readFile(target);res.setHeader('Content-Type',target.endsWith('.png')?'image/png':target.endsWith('.js')?'text/javascript':'text/html');res.end(body);}
  catch{res.writeHead(404);res.end()}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const url=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({headless:true});
try{
 const page=await browser.newPage({viewport:{width:1600,height:1050},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto(url+'/preview.html');
 await page.evaluate(async()=>{await Promise.all([...document.images].map(i=>i.decode()))});
 const assets=await page.evaluate(()=>{
   return [...document.querySelectorAll('.building')].map(img=>{
     const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;
     const ctx=c.getContext('2d');ctx.drawImage(img,0,0);
     const a=ctx.getImageData(0,0,c.width,c.height).data;let transparent=0,solid=0,partial=0,maxAlpha=0;
     for(let i=3;i<a.length;i+=4){maxAlpha=Math.max(maxAlpha,a[i]);if(a[i]===0)transparent++;else if(a[i]>=240)solid++;else partial++}
     return {name:img.alt,width:c.width,height:c.height,transparent,solid,partial,maxAlpha,hasAlpha:transparent>0&&solid>0};
   });
 });
 if(assets.length!==18||assets.some(a=>!a.hasAlpha))throw Error('Missing building or invalid transparency: '+JSON.stringify(assets));
 await page.locator('#stage').screenshot({path:path.join(root,'assembled-preview.png')});
 await page.locator('#none').click();
 if(await page.locator('.building:visible').count()!==0)throw Error('Background toggle failed');
 await page.locator('#all').click();
 if(await page.locator('.building:visible').count()!==18)throw Error('Show all failed');
 await page.locator('#list button').first().click();
 await page.locator('#width').fill('30');
 await page.locator('#width').dispatchEvent('input');
 if(await page.locator('.building').first().evaluate(i=>i.style.width)!=='30%')throw Error('Resize failed');
 const download=page.waitForEvent('download');await page.locator('#export').click();
 if((await download).suggestedFilename()!=='greek-city-placements.json')throw Error('Export failed');
 await page.locator('#reset').click();
 await page.locator('#reference').click();
 if(!await page.locator('#concept').isVisible())throw Error('Concept toggle failed');
 await page.goto(url+'/contact-sheet.html');await page.evaluate(async()=>{await Promise.all([...document.images].map(i=>i.decode()))});
 await page.screenshot({path:path.join(root,'contact-sheet.png'),fullPage:true});
 if(errors.length)throw Error(errors.join('\n'));
 await writeFile(path.join(root,'validation.json'),JSON.stringify({assets,checks:['18 images load','transparent backgrounds','hide/show all','resize','export JSON','reset','concept toggle','no JavaScript errors']},null,2));
 console.log(JSON.stringify({ok:true,assets:assets.length,root}));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
